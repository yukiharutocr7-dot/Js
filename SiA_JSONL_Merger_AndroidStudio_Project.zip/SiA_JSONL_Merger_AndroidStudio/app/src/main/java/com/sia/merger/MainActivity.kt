package com.sia.merger

import android.content.ContentResolver
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.InputStream
import java.io.OutputStream

private val Bg = Color(0xFF0B0D10)
private val Panel = Color(0xFF15191F)
private val Gold = Color(0xFFD5B46A)
private val MainText = Color(0xFFF1F2F4)
private val Muted = Color(0xFF9BA3AE)

private data class PickedFile(val uri: Uri, val name: String)
private data class MergeResult(val lines: Long, val bytes: Long)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(11, 13, 16)
        window.navigationBarColor = android.graphics.Color.rgb(11, 13, 16)
        setContent { MergerScreen(contentResolver) }
    }
}

@Composable
private fun MergerScreen(resolver: ContentResolver) {
    val scope = rememberCoroutineScope()
    var files by remember { mutableStateOf<List<PickedFile>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var status by remember { mutableStateOf("اختر ملفات JSONL التي تريد دمجها") }
    var result by remember { mutableStateOf<MergeResult?>(null) }
    var pendingOutputName by remember { mutableStateOf("SiA_Merged_400000.jsonl") }

    val pickFiles = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            scope.launch {
                val names = withContext(Dispatchers.IO) { uris.map { uri -> PickedFile(uri, displayName(resolver, uri)) } }
                files = names
                result = null
                status = "تم اختيار ${names.size} ملفًا. راجع الترتيب قبل الدمج."
            }
        }
    }
    val createOutput = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { outputUri ->
        if (outputUri != null) {
            val chosen = files.toList()
            scope.launch {
                busy = true; progress = 0f; result = null; status = "جارٍ دمج الملفات… لا تغلق التطبيق."
                try {
                    val merged = withContext(Dispatchers.IO) {
                        mergeFiles(resolver, chosen, outputUri) { done, total ->
                            scope.launch(Dispatchers.Main) { progress = if (total > 0L) (done.toDouble() / total.toDouble()).toFloat().coerceIn(0f, 1f) else 0f }
                        }
                    }
                    result = merged
                    progress = 1f
                    status = "اكتمل الدمج بنجاح."
                } catch (e: Exception) {
                    status = "فشل الدمج: ${e.localizedMessage ?: e.javaClass.simpleName}"
                } finally { busy = false }
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Bg, surface = Panel, onBackground = MainText, onSurface = MainText)) {
        Column(Modifier.fillMaxSize().background(Bg).padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(48.dp).background(Gold, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                    Text("SiA", color = Bg, fontWeight = FontWeight.Black, fontSize = 17.sp)
                }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("SiA JSONL Merger", color = MainText, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("OFFLINE · BYTE-PRESERVING MERGE", color = Gold, fontSize = 9.sp, letterSpacing = 1.sp)
                }
            }
            Spacer(Modifier.height(22.dp))
            Text("دمج ملفات التدريب", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MainText)
            Spacer(Modifier.height(5.dp))
            Text("اختر 4 ملفات × 100,000 سجل لتحصل على ملف واحد بحوالي 400,000 سجل.", color = Muted, fontSize = 13.sp, lineHeight = 19.sp)
            Spacer(Modifier.height(14.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("الملفات المختارة", color = Gold, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Spacer(Modifier.height(5.dp))
                    Text("${files.size} ملف", color = MainText, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text("يتم الدمج حسب الترتيب الظاهر أدناه.", color = Muted, fontSize = 11.sp)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { pickFiles.launch(arrayOf("*/*")) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                        Text(if (files.isEmpty()) "اختيار ملفات JSONL" else "اختيار / استبدال الملفات")
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            if (files.isNotEmpty()) {
                LazyColumn(Modifier.weight(1f, fill = true), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    itemsIndexed(files) { index, file ->
                        Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(10.dp)).padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("${index + 1}", color = Gold, fontWeight = FontWeight.Bold, modifier = Modifier.width(28.dp))
                            Column(Modifier.weight(1f)) {
                                Text(file.name, color = MainText, fontSize = 12.sp, maxLines = 2)
                                Text("سيُنسخ المحتوى كما هو", color = Muted, fontSize = 10.sp)
                            }
                        }
                    }
                }
            } else {
                Spacer(Modifier.height(8.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("لا توجد ملفات مختارة", color = Muted, fontSize = 14.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("يدعم ملفات JSONL الكبيرة؛ لا يحتاج رفعًا للإنترنت.", color = Muted, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(12.dp))
            if (busy) {
                LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth(), color = Gold, trackColor = Panel)
                Spacer(Modifier.height(7.dp))
            }
            Text(status, color = if (status.startsWith("فشل")) Color(0xFFFF8A80) else Muted, fontSize = 12.sp, lineHeight = 17.sp)
            result?.let {
                Spacer(Modifier.height(8.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(12.dp)) {
                    Column(Modifier.fillMaxWidth().padding(13.dp)) {
                        Text("نتيجة الدمج", color = Gold, fontWeight = FontWeight.Bold)
                        Text("عدد الأسطر: ${it.lines}", color = MainText, fontSize = 15.sp)
                        Text("حجم الملف: ${formatBytes(it.bytes)}", color = MainText, fontSize = 13.sp)
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Button(onClick = { pendingOutputName = "SiA_Merged_${files.size}_files.jsonl"; createOutput.launch(pendingOutputName) }, enabled = files.isNotEmpty() && !busy, modifier = Modifier.fillMaxWidth()) {
                Text("دمج وحفظ ملف JSONL واحد")
            }
            Spacer(Modifier.height(5.dp))
            Text("لا يتم تحليل السجلات أو إعادة تنسيقها. يضاف فاصل سطر فقط بين ملفين إذا كان الملف السابق لا ينتهي بسطر جديد.", color = Muted, fontSize = 10.sp, lineHeight = 14.sp)
        }
    }
}

private fun displayName(resolver: ContentResolver, uri: Uri): String {
    return try {
        resolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) ?: "ملف بدون اسم" else "ملف بدون اسم"
        } ?: "ملف بدون اسم"
    } catch (_: Exception) { uri.lastPathSegment ?: "ملف بدون اسم" }
}

private suspend fun mergeFiles(
    resolver: ContentResolver,
    files: List<PickedFile>,
    outputUri: Uri,
    onProgress: (Long, Long) -> Unit
): MergeResult {
    require(files.isNotEmpty()) { "اختر ملفًا واحدًا على الأقل" }
    val sizes = files.map { file ->
        try { resolver.openAssetFileDescriptor(file.uri, "r")?.use { it.length.coerceAtLeast(0L) } ?: 0L } catch (_: Exception) { 0L }
    }
    val totalBytes = sizes.sum().coerceAtLeast(1L)
    var bytesWritten = 0L
    var lineCount = 0L
    resolver.openOutputStream(outputUri, "wt")?.use { rawOut ->
        val out = BufferedOutputStream(rawOut, 1024 * 1024)
        files.forEachIndexed { index, file ->
            resolver.openInputStream(file.uri)?.use { rawIn ->
                val input = BufferedInputStream(rawIn, 1024 * 1024)
                val buffer = ByteArray(256 * 1024)
                var lastByte = -1
                var fileBytes = 0L
                var newlineCount = 0L
                var hasBytesAfterLastNewline = false
                while (true) {
                    val n = input.read(buffer)
                    if (n < 0) break
                    out.write(buffer, 0, n)
                    fileBytes += n
                    for (i in 0 until n) {
                        val b = buffer[i].toInt() and 0xff
                        if (b == 10) { newlineCount++; hasBytesAfterLastNewline = false }
                        else if (b != 13) hasBytesAfterLastNewline = true
                    }
                    lastByte = buffer[n - 1].toInt() and 0xff
                    bytesWritten += n
                    onProgress(bytesWritten, totalBytes)
                }
                lineCount += newlineCount
                if (fileBytes > 0 && lastByte != 10) {
                    // JSONL requires a line boundary between adjacent files; preserve all original bytes.
                    if (index < files.lastIndex) { out.write('\n'.code); bytesWritten++ }
                    lineCount++
                }
            } ?: throw IllegalStateException("تعذر فتح الملف: ${file.name}")
        }
        out.flush()
    } ?: throw IllegalStateException("تعذر إنشاء ملف الإخراج")
    return MergeResult(lineCount, bytesWritten)
}

private fun formatBytes(bytes: Long): String {
    val mb = bytes / (1024.0 * 1024.0)
    return if (mb >= 1024) String.format("%.2f GB", mb / 1024.0) else String.format("%.2f MB", mb)
}
